
package Managed_Bean;
import controller.CartFacadeLocal;
import controller.OrderRecordFacadeLocal;
import controller.ProductFacadeLocal;
import entites.*;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.util.*;
import java.io.Serializable;
@Named(value = "showHistoryOrders")
@SessionScoped
public class ShowHistoryOrders implements Serializable{
    private String name="rename";      
     public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    @EJB
    private OrderRecordFacadeLocal orderRecordFacade;
    @EJB
    private ProductFacadeLocal productFacade;
     @EJB
    private CartFacadeLocal cartFacade;
    public List<Product> showAllProduct()
    {
        return productFacade.findAll();
    }
    public List<OrderRecord> showAllRecordByUser()
    {
          return orderRecordFacade.findRecordByName(name);
    }
    public List<Ordering> showAllOrders(OrderRecord ordrec)
    {
        return ordrec.getOrderingList();
    }
    public ShowHistoryOrders() {
    }

    
}
