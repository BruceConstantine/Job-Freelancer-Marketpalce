/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entites.OrderRecord;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
/**
 *
 * @author Lenovo
 */
@Stateless
public class OrderRecordFacade extends AbstractFacade<OrderRecord> implements OrderRecordFacadeLocal {

    @PersistenceContext(unitName = "TestF-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public OrderRecordFacade() {
        super(OrderRecord.class);
    }

    @Override
    public List<OrderRecord> findRecordByName(String name) {
      Query query=em.createNamedQuery("OrderRecord.findByName").setParameter("username", name);
      return query.getResultList();
    }
    
    
}
